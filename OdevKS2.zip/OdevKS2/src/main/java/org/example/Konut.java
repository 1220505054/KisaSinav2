package org.example;

public abstract class Konut {
    String adress;
    Konut (String adress){
    this.adress=adress;

    }

    public void displayInfo() {

    }
    //{
       // System.out.println("Konut bu adreste bulunmaktadir:" +adress);

    //}
}
