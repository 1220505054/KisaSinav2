package org.example;

 public class Daire extends Konut implements Comparable<Daire>{
  private int apartmentNum;

     Daire(String adress,int apartmentNum) {
         super(adress);
         this.setApartmentNum(apartmentNum);

     }

     @Override
     public void displayInfo() {
         super.displayInfo();
        System.out.println("Daire adresi: " +adress +"\tDaire Numarasi: " +getApartmentNum());
     }

     @Override
     public int compareTo(Daire other) {
         return this.apartmentNum -other.apartmentNum;
     }
     public int getApartmentNum() {
         return apartmentNum;
     }

     public void setApartmentNum(int apartmentNum) {
         this.apartmentNum = apartmentNum;
     }
 }
